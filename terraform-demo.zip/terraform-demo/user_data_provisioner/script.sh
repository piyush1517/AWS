#!/bin/bash
df -h >> /tmp/size.txt